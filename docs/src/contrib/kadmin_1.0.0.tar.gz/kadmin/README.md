[![Build Status](https://travis-ci.org/SYOUNG9836/k_admin_shp.svg?branch=main)](https://travis-ci.com/github/SYOUNG9836/k_admin_shp)

# k_admin_shp

For more on using this R package, see the GitHub repository for the [k_admin_shp package](https://github.com/SYOUNG9836/k_admin_shp). The Administrative districts of Korea shapefile are included in this package `k_admin_shp`. the `*rda` file `k_admin_shp.rda` is around 68 MB in size.

 
## Installation

```
install.packages('k_admin_shp', repos='https://github.com/SYOUNG9836/k_admin_shp/', type='source')
```

