#' @name kadmin
#' @title Administrative districts of Korea shapefile, sido, sigungu, eupmyeondong
#'
NULL


#' do
#'
#' @description
#' Administrative districts of Korea shapefile, sido
#' 
#' @name do
#' @export
"do"


#' sgg
#'
#' @description
#' Administrative districts of Korea shapefile, sigungu
#' 
#' @name sgg
#' @export
"sgg"


#' emd
#'
#' @description
#' Administrative districts of Korea shapefile, eupmyeondong
#' 
#' @name emd
#' @export
"emd"


