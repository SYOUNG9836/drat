#' do
#'
#' @description
#' Administrative districts of Korea shapefile, sido
#' @source http://www.gisdeveloper.co.kr/?p=2332
#' @name do
#' 
"do"


#' sgg
#'
#' @description
#' Administrative districts of Korea shapefile, sigungu
#' @source http://www.gisdeveloper.co.kr/?p=2332
#' @name sgg
#' 
"sgg"


#' emd
#'
#' @description
#' Administrative districts of Korea shapefile, eupmyeondong
#' @source http://www.gisdeveloper.co.kr/?p=2332
#' @name emd
#' 
"emd"


